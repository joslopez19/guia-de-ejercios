package calculoperimetroarea;

import java.util.Scanner;

public class Main {
	
    public static final double PI = 3.14; 
    
	public static void main(String[] args) {
		//Determinar el Perímetro de una circunferencia y el área de un círculo

		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese el radio");
		double r = sc.nextDouble();
		double perimetro  = 2*PI*r;
		double area = PI*Math.pow(r, 2);
		System.out.println("El perimetro es:"+perimetro);
		System.out.println("El area es:"+area);
		
	
		
		
		
		
	}

}
