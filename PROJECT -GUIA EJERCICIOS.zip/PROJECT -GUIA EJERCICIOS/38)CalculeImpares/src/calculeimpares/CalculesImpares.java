package calculeimpares;

import java.util.Scanner;

public class CalculesImpares {

	public static void main(String[] args) {
		//38.Escriba un programa que calcule cuantos números impares hay 
		//entre 20 y 100 e igualmente a cuantos asciende la suma de ellos. 
		
		Scanner sc = new Scanner(System.in);
		
		int cont =0;
		int sum =0;
		
		for (int i=20; i<=100; i++) {
			
			if (i%2!=0) {
				cont++;
				sum+=i;
			}
			
		}
      System.out.println("Los numero impares entre 20 y 100 son ="+cont);
      System.out.println("Los suma impares entre 20 y 100 son ="+sum);
	}

}
