package leernnumero;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// Escriba un programa que lea “n” números enteros y que los imprima

		Scanner tc = new Scanner(System.in);
		int x, num;

	System.out.println("ingrese el numero a evaluar");
	 x = tc.nextInt();
	
	
	for (int i=0; i<=x; i++) {
		
		System.out.println("ingrese el numero");
		
		num =tc.nextInt();
		System.out.println("Elnumero entero es "+num);
		
		
	}
				

		
}
		

}