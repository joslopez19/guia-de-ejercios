package LeaNumEnt;

import java.util.Scanner;

public class LeerNumeroEnteros {

	public static void main(String[] args) {
		// 28.Escriba un programa que lea dos números enteros como entrada y escriba
		//el mensaje signos opuestos si y solo si uno de los enteros es
		//positivo y el otro negativo
		
		Scanner st = new Scanner(System.in);
		
		int num1 = 'n';
		int num2 = 'n';
		
		System.out.println("Ingrese el primer numero entero ");
		num1 = st.nextInt();
		System.out.println("Ingrese el segurndo numero enetero");
		num2 = st.nextInt();
		
		if ((num1 > 0 && num2 <0)|| (num1 < 0 && num2 > 0)) {
			
			System.out.println("Signos opuestos");
			
		}else {
			System.out.println("No son signos opuestos");
			
		}
		

	}

}
