package arearectangulo;

import java.util.Scanner;

public class Main{

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
	
       System.out.println("Ingrese la base");
       double b=sc.nextDouble();
       System.out.println("Ingrese la altura");
       double h=sc.nextDouble();
       double area = b*2 + h*2;
       System.out.println("El area es"+area);
       
         
       
	}

}
