package pareseimpares;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 20.Escriba un programa que lea un número cualquiera e imprima si es par o impar. 

	       Scanner scanner = new Scanner(System.in);
	        System.out.print("Ingrese un número");
	        
	        int numero = scanner.nextInt();
	        if (numero % 2 == 0) {
	        	
	            System.out.println("El número ingresado " + numero + " es par.");
	        } else {
	            System.out.println("El número ingresado " + numero + " es impar.");
	        }
	    }
	}