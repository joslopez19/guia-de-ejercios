package sistemEcuaLineal;

public class Cramer {
	
	public static void main (String []args) {
		
        double a = 2;
        double b = 3;
        double c = 6;
        double d = 5;
        double e = 4;
        double f = 7;

        double denominator = a * e - b * d;
        if (denominator == 0) {
            System.out.println("El sistema no tiene solución única.");
            
            
        } else {
            double x = (c * e - b * f) / denominator;
            double y = (a * f - c * d) / denominator;
            
            
            System.out.println("La solución del sistema de ecuacion lineal es : X = " + x);
            System.out.println("La solución del sistema de ecuacion lineal es : Y = " + y);
        }
	}

}
