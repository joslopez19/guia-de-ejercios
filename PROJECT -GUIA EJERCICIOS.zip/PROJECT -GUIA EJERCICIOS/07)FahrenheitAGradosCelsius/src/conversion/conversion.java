package conversion;

import java.util.Scanner;

public class conversion {
	
 public static void main(String[] args) {
	 /*7) Convertir X grados Fahrenheit a grados Celsius. Celsius= 5/9 (Fahrenheit -323). */
			
	Scanner sc = new Scanner(System.in);
	float  c,f;
	
	System.out.println("Ingresa los grados Fahrenheit ");
	f = sc.nextFloat();
	
	c = (f-32)* 5/9;
	System.out.println("+grados Fahrenheit convertidos a grados celsius es: "+c);
	
	
	
	
	 
 }

}
