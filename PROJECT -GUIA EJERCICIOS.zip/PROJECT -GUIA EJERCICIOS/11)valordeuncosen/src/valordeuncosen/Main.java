	package valordeuncosen;

	import java.util.Scanner;
	
public class Main {

	public static void main(String[] args) {
		// 11. Obtener el valor del Coseno de un número cualquiera. 
		// se asigna dos variables y se le agregan valores
		
		Scanner sc =new Scanner(System.in);
		double numx = 45; // se le asigna valor a la variable, 
	    double numy = 30;  // se ingresa variable con diferente valor
		
		System.out.println("Ingrese el valor de numero");
		numx = sc.nextDouble();
		System.out.println("Ingrese el valor de numero");
		numy = sc.nextDouble();
		
		
		numx = Math.cos(numx); 
		numy = Math.cos(numy);
		
		System.out.println("El valor del Coseno del primer # es ="+numx);
		System.out.println("El valor del conseno del segundo # es ="+numy);
		
		

	}

}
