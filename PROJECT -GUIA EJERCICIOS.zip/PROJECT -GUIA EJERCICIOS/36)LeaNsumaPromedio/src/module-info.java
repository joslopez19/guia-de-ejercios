/**
 * 
 */
/**
 * @author DELL 5580
 *
 */
module LeaNsumaPromedio {
}