package leaNsumapromedio;

import java.util.Scanner;

public class LeaNsumapromedio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
	
		double n;
		
		System.out.println("Ingrese el numero a leer");
		n = sc.nextDouble();
	
		
		double sum =0;
		
		for (int i=0; i<n; i++) {
		
		System.out.println(" Introduzca el numero");
		
		double num =sc.nextDouble();
		sum+=num;

	}
		double prom = sum/n;
		System.out.println("La suma  de los "+n+" numeros es "+sum);
		
		System.out.println("La suma  de los "+n+" numeros es "+prom);
		
	}
}
