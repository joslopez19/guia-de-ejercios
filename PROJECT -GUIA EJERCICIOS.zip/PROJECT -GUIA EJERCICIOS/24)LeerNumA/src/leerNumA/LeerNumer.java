package leerNumA;

import java.util.Scanner;

public class LeerNumer {
	
	public static void main (String[] args){
		//. Escriba un programa que lea un numero A, si A es un número positivo calcule Y=2^A, si es 
		//negativo calcule Y=A+5 imprimir el resultado de Y.
		
		Scanner sc = new Scanner(System.in);
	     //declaramos variables
		int a;
		int y;
	
	    System.out.println("Ingrese el numero: "); 
	     a = sc.nextInt();
	        
	        if (a >= 0) {
	            y = (int) Math.pow(2, a);
	        } else {
	            y = a + 5;
	        }
	        System.out.println("El resultado de  Y es = " + y);
	   
		
	}

}
