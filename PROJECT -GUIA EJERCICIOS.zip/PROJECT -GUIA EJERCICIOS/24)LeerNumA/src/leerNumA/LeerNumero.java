package leerNumA;

public class LeerNumero {

}
