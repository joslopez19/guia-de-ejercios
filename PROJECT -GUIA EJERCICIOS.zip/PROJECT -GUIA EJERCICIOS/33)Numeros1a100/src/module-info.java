/**
 * 
 */
/**
 * @author DELL 5580
 *
 */
module Numeros1a100 {
}