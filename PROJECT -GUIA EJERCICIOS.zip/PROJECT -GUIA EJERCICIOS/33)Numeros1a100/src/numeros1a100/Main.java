package numeros1a100;

import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// Escriba un programa que imprima los números del 1 al 100.

		Scanner sc = new Scanner(System.in);
		
		int num, n=100;
		  
		System.out.println("Ingrese el numero uno");
		num = sc.nextInt();
		
		 for (int i = 1; i <= 100; i++) {
	            if (i % 2 == 0) {
			
		}
            System.out.println(i);
            
		
		 }		
				
		
	}

}
