package leerNumeroX;

import java.util.Scanner;

public class LeerNumero {
	
	public static void main(String [] args ) {
		//21.Escriba un programa que lea un número que verifique si X es negativo que calcule X^4 en caso contrario que calcule X^2. 
		
		Scanner sc= new Scanner(System.in);
		
		double x = 'n';
		
		 System.out.print("Ingrese un número a calcular :");
	       x = sc.nextDouble();
	       
	        if (x < 0) {
	        	
	            double Numx = Math.pow(x, 4);
	            System.out.println("El resultado es: " + Numx);
	            
	        } else {
	        	
	            double Numx = Math.pow(x, 2);
	            System.out.println("El resultado es: " + Numx);
	            
	        }    
	}

}
