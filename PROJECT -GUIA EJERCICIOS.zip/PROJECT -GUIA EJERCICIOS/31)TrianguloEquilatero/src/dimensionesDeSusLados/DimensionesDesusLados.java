package dimensionesDeSusLados;

import java.util.Scanner;

public class DimensionesDesusLados {

	public static void main(String[] args) {
		// 31.	UN triángulo es equilátero si posee sus tres lados iguales, 
		//es Isósceles si tiene solamente dos lados iguales y es escaleno cuando 
		//todos sus lados son desiguales. Escribir un programa que lea las dimensiones 
		//de los lados del triángulo y presente como salida el mensaje de su clasificación de triangulo. 
		
 Scanner sc =new Scanner(System.in);
 
 double long1 = 'n';
 double long2 = 'n';
 double long3 = 'n';
 
 System.out.println("Ingrese la primera logitud de sus lados");
 long1 = sc.nextDouble();
 
 System.out.println("Ingrese la segunda logitud de sus lados");
 long2 = sc.nextDouble();
 
 System.out.println("Ingrese la tercera logitud de sus lados");
 long3 = sc.nextDouble();
 
 if  (long1 == long2 && long2 == long3){
	 
 System.out.println("El Trinagulo es Equilatero");
 
  } else if (long1 == long2 || long2 == long3 || long1 == long3){ 
  System.out.println("El Triangulo es Isoceles");
  
	 
   } else {
	 
	 System.out.println("El Triangulo es Escaleno");
 }
		
}

}
