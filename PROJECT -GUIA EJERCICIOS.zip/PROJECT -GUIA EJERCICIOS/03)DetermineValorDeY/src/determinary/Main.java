package determinary;

import java.util.Scanner;

public class Main {

	static final int C=(int) 2.5-2;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double numy, numx=2, c=2.5, z=(-2);
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduce un numero numx ");
		numx=sc.nextDouble();
		System.out.println("Introduce un numero numC ");
		c=sc.nextDouble();
		System.out.println("ingrese el numero negativo");
		z=sc.nextDouble();
		
	numy=numx*c-z;{
		 
		}
		 

		System.out.println("El valor de numy es:"+numy);
		
		
	}

}

