package areadeuntriangulo;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// calcule el area de un triangulo conociendo sus tres lado
		
		Scanner sc = new Scanner(System.in);
		
		 float base;
		 float altura;
		 float area;
		 
		 System.out.println("Ingresa la base del traiangulo");
		 base = sc.nextFloat();
		 System.out.println("Ingresa la altura del traiangulo"); 
		 altura = sc.nextFloat();
		 
		 area = (base * altura)/2;
		 
		 System.out.println("El area de un triangulo es:"+area);
		 

	}

}
