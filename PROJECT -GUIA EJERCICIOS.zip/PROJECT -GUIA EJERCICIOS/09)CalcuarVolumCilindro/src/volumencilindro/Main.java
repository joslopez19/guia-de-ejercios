package volumencilindro;

import java.util.Scanner;

public class Main {
	
	public static final double PI=3.1416;

	public static void main(String[] args) {
		// 9.	Calcular el volumen de un cilindro conociendo su radio y altura. 
		//V = π* R2*h
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingrese el valor del radio");
		double r = sc.nextDouble();
		System.out.println("Ingresa el valor de la altura");
		double h = sc.nextDouble();
		
		double v=(Math.PI*Math.pow(r, 2)*h);
		System.out.println("El Volumne del cilindro es:"+v);
		
		
	}

}
