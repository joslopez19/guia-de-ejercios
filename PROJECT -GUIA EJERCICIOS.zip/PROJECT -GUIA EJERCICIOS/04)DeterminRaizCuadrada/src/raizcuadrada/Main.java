package raizcuadrada;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		// Determine las Raiz Cuadrada de cuaquier numero 
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingrese el numero");
		int num1 = sc.nextInt();
		double raiz = Math.sqrt(num1);
		
		System.out.println("La raiz del numero:"+num1+"es:"+raiz);
		
		
	
		
	}

}
