package divisblePorTres;

import java.util.Scanner;

public class Divisible {
	
	public static void main (String [] args) {
		//Escribir un programa que lea un número cualquiera e imprima si el número leído es 
		//divisible por tres.
		Scanner sc= new Scanner(System.in);
		
		int x = 'n';
		
		
		System.out.println("Ingrese el numero");
		x =sc.nextInt();
		
		if  (x%3==0){
			
			System.out.println("numero es divisible por 3.");
		}else {
			System.out.println("el numero no es divisible por 3");
			
		}
		
		
	}

}
