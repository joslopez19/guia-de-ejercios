package invertirNumero;

import java.util.Scanner;

public class NumeroInvertido {
	
 public static void main (String [] args) {
	 // 18.Leer un número de tres cifras e imprimirlo en orden invertido Ejemplo Entrada: 567   Salida 765. 
	 
	 Scanner sc = new Scanner(System.in);
	 
	 int num = 567;          
	 
	 System.out.println("Ingresa el numero a invertir");
	 num =sc.nextInt();
	 
     int unos      = num % 10;
     int decenas   = (num / 10) % 10;
     int cientos   = num / 100;
     int invertNum = unos * 100 + decenas * 10 + cientos;
     
     
     System.out.println("El número invertido es =: " + invertNum);
     
     
 }

}
