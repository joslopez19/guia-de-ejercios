package kilogramosalibra;

import java.util.Scanner;

public class Main {

public static void main(String[] args) {
		// 6.Convertir N kilogramos a Libras. 

   Scanner sc = new Scanner(System.in);
	
   double kilogramos = 1, lbs=2.20462;

   System.out.println("Ingresa el numero de Kg a convertir");	
   kilogramos= sc.nextDouble();

	lbs=kilogramos*lbs;	

	System.out.println("las libra:"+lbs);
	
	 
       }
		
		
	}


