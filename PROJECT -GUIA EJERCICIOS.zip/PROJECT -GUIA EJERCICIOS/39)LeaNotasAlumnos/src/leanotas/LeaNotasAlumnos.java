package leanotas;

import java.util.Scanner;

public class LeaNotasAlumnos {

	public static void main(String[] args) {
		// 39.	Escriba un programa que lea las notas de “N” alumnos y calcule cuantos aprobados y 
		//desaprobados hay (está aprobado si la nota es mayor de 60). 
		
		Scanner sc = new Scanner(System.in);
		
		int n= 10;
		
		System.out.println("Ingrese el numero de estudiantes");
		n = sc.nextInt();
		
		int aprobaron =0;
		int reprobaron =0;
		
		for (int i=0; i<5; i++) {
			
			System.out.println("Ingresa la calidicaion del estudiante");
			int calif = sc.nextInt();
			
			if (calif>60) {
				aprobaron++;
				
			}else {
				reprobaron++;
			}
		}
		System.out.println("El numero de estudiantes que Aprobaron son "+aprobaron);
		System.out.println("El numero de estudiantes que Reprobaron son "+reprobaron);
	}

}
