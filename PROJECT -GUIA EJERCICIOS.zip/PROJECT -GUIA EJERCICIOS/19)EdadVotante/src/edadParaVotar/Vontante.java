package edadParaVotar;

import java.util.Scanner;

public class Vontante {
	
	public static void main (String [] args) {
		//19.Escriba un programa que lea la edad de una persona e imprima es votante dado que tiene 16 o más años de edad.
		
		Scanner sc = new Scanner(System.in);
		
		int edad =16;
		
		System.out.println("Ingrese la edad del votante");
		edad = sc.nextInt();
		
		if (edad >=16) {
			
			System.out.println("Usted es vontante");
			
		}else {
				
			System.out.println("Usted no es votante");
		}
		
		
		
		
		
	}

}
