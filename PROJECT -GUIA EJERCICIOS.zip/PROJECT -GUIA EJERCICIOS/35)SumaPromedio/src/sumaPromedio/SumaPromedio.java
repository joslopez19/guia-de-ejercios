package sumaPromedio;

import java.util.Scanner;

public class SumaPromedio {

	public static void main(String[] args) {
		// 35.	Escriba un programa que lea tres números cualesquiera y que calcule 
		//la suma de ellos y su promedio. 
		
		Scanner sc = new Scanner(System.in);
		
		double num1=6;
		double num2=8;
		double num3=10;
		
		
		System.out.println("Ingrese el primer numero");
		num1 = sc.nextDouble();
		System.out.println("Ingrese el segundo numero");
		num2 = sc.nextDouble();
		System.out.println("Ingrese el tercer numero");
		num3 = sc.nextDouble();
		
		double sum =num1+num2+num3;
		
		System.out.println("La suma es de los tres numero es = "+sum);
		
		double promedio = sum/3;
		
		System.out.println("El promedio de los tres numero es = " +promedio);
		
		
		
		

	}

}
