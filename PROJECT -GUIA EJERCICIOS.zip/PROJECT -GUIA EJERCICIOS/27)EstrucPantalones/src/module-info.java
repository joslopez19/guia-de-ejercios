/**
 * 
 */
/**
 * @author DELL 5580
 *
 */
module EstrucPantalones {
}