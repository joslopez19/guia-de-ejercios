package estructuraPantal;

import java.util.Scanner;

public class Pantalones {

	public static void main(String[] args) {
		// 27.	Unos pantalones se venden a 10 dólares cada uno si se compran más de tres,
		//12 dólares en los demás casos, estructure un programa que lea un número de entrada 
		//de pantalones comprados e imprima el costo total. 
		
		Scanner st =new Scanner(System.in);
		
		int num = 'n';
		System.out.println("Ingrese el numero de pantalones");
	    num = st.nextInt();
	    
	    int costPant = (num>3) ? 10 :12;
	    
	    int totalCost = num*costPant;
	    
	    System.out.println("El total de costo es $"+totalCost);
	    
	    
		
		

	}

}
