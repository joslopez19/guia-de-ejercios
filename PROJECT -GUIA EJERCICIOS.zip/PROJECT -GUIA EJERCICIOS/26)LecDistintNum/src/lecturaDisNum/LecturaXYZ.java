package lecturaDisNum;

import java.util.Scanner;

public class LecturaXYZ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
     Scanner sc = new Scanner(System.in);
		
		String xyz;
		
		
		
		
		System.out.println("Ingrese el numeroe en formato XYZ");
		xyz  = sc.nextLine();
	
	
     int x = Character.getNumericValue(xyz.charAt(0));
     
     int y = Character.getNumericValue(xyz.charAt(1));
     
     int z = Character.getNumericValue(xyz.charAt(2));
     
   
     
     
     System.out.println("El valor de x es ="+ x);
     System.out.println("El valor de x es ="+ y);
     System.out.println("El valor de x es ="+ z);
     

	}

}
