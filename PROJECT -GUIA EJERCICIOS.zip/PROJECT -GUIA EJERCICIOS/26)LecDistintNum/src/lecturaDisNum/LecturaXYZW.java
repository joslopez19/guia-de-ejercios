package lecturaDisNum;

import java.util.Scanner;

public class LecturaXYZW {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner sc = new Scanner(System.in);
		
		String xyzw;
		
		
		
		
		System.out.println("Ingrese el numeroe en formato XYZW");
		xyzw  = sc.nextLine();
	
	
     int x = Character.getNumericValue(xyzw.charAt(0));
     
     int y = Character.getNumericValue(xyzw.charAt(1));
     
     int z = Character.getNumericValue(xyzw.charAt(2));
     
     int w = Character.getNumericValue(xyzw.charAt(3));
     
     
   
     
     
     System.out.println("El valor de x es ="+ x);
     System.out.println("El valor de x es ="+ y);
     System.out.println("El valor de x es ="+ z);
     System.out.println("El valor de x es ="+ w);
     

	}

}
