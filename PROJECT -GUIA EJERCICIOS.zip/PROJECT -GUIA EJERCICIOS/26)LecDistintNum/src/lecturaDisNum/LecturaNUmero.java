package lecturaDisNum;

import java.util.Scanner;

public class LecturaNUmero {
	
	public static void main( String [] args) {
		
		//. Escriba un programa independiente para cada inciso considerando una lectura de distintos 
		//números tal como se detallan a continuación. 
		//a) XY b) XYZ c) XYZW
		
		Scanner sc = new Scanner(System.in);
		
		String xy;
	
		
		
		System.out.println("Ingrese el numeroe en formato XY");
		xy  = sc.nextLine();
	
	
     int x = Character.getNumericValue(xy.charAt(0));
     
     int y = Character.getNumericValue(xy.charAt(1));
     
   
     
     
     System.out.println("El valor de x es ="+ x);
     System.out.println("El valor de x es ="+ y);
     
     
     
 
		
	}

}
