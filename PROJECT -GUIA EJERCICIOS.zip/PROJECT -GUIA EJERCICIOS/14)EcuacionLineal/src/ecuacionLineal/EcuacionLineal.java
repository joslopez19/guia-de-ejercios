package ecuacionLineal;

import java.util.Scanner;

public class EcuacionLineal {

	public static void main(String[] args) {
		
		// 14.Determinar la solución lineal que tiene la forma ax + b =0 donde a y b son números reales. 
		//ax+b=0  Resolver esta Ecuacion Lineal
		// ax=-b  Es el resultado de restar b ambos lados
		//xa/x = -b/x al dividir por x se deshace la multiplicacion
		// a=-b/a queda como resultado
		
		Scanner sc = new Scanner(System.in);
		
		  double a = 5;
	      double b = 10;
	      double x= 'n';
	      
	      System.out.println("Ingresarla variable a");
	      a=sc.nextDouble();
	      System.out.println("Ingresa la variable b");
	      b=sc.nextDouble();
	      
	      
	      x = -b/a;
	     
	        
	        System.out.println("La solución de la ecuación es = "+x);
	    }
	

	}


