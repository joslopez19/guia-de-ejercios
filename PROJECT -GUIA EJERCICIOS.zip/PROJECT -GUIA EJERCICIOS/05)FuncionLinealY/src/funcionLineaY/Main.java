package funcionLineaY;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 5.Evaluar la Función Y= 5X^4 + 2X^3 + 3X^2 + 7 para el valor de  
		//a) X=1; 
		//b) X un número cualquiera. 
		// se ingresan otra variables agregandole un valor diferente,
		
		int x = 1;
		int z =2; 
		int w =3;
		int v= 4;
		double f;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingrese el valor de x");
		x = sc.nextInt();
		System.out.println("Ingrese el valor de z");
		z = sc.nextInt();
		System.out.println("Ingrese el valor de w");
		w =sc.nextInt();
		System.out.println("Ingrese el valor de v");
		v =sc.nextInt();
		
		double y = 5* Math.pow(x, 4) + 2*Math.pow(x, 3) + 3*Math.pow(x, 2)+7;
        System.out.println("El valor de  X es ="+ y);
        
        double a = 5* Math.pow(z, 4) + 2*Math.pow(z, 3) + 3*Math.pow(z, 2)+7; 
        System.out.println("El valor de Z es ="+ a);
       
        double b = 5* Math.pow(w, 4) + 2*Math.pow(w, 3) + 3*Math.pow(w, 2)+7;
        System.out.println("El valor de W es ="+ b);
        
        double c = 5* Math.pow(v, 4) + 2*Math.pow(v, 3) + 3*Math.pow(v, 2)+7;
        System.out.println("El valor de V es ="+ c);
        
	}

}
