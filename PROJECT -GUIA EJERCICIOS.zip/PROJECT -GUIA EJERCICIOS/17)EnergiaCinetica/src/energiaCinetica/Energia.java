package energiaCinetica;

import java.util.Scanner;

public class Energia {
	
	 public static void main(String[] args) {
//17.Determinar la energía total que almacena un cuerpo si su energía cinética es ½ de la masa por su velocidad al cuadrado y 
// la energía potencial es el producto de la masa, altura y la constante de gravedad. Recuerde que ET = EC +EP. 
		// detalle de formulas:
		 //EC = 1/2 * m * v^2,
		 //EP = m * g * h
		 // ET = EC + EP 
		 
		 Scanner sc = new Scanner(System.in);
		 
	        double m = 10;             //masa 
	        double v = 5;              // velocidad
	        double a = 20;             // altura
	        double g = 9.8;            // gravedad
	        
	        System.out.println("Ingrese el valor de la masa");
	        m = sc.nextDouble();
	        System.out.println("Ingrese el valor de la velociada");
	        v = sc.nextDouble();
	        System.out.println("Ingrese el valor de la altura");
	        a = sc.nextDouble();
	        System.out.println("Ingrese el valor de la gravedad");
	        g = sc.nextDouble();
	        
	        

	        double  EC= 0.5 * m * Math.pow(v, 2);            //Energia cinetica
	        double  EP = m * g * a;                          //Energia pontencial
	        double  ET = EC + EP;                            //Energia total  
	        
	        System.out.println("La energía cinética del cuerpo es:= "+ EC);
	        System.out.println("La energía potencial del cuerpo es: = "+ EP);
	        System.out.println("La energía total del cuerpo es: = "+ ET);

  }
}
