package valordelafuerza;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		// 10.Determine el valor de la fuerza de un cuerpo que tiene por masa “M” y aceleración “A”. 
		//le asignamos valores a las variables
		//formula   F=m*a
		
		Scanner sc = new Scanner(System.in);
		
		double m = 4;   // masa en kilogramos 
		double a = 6;   // aceleración en m/s²
		double f = 'n';
		
		System.out.println("Ingrese el valor de masa");
		m = sc.nextDouble();
		System.out.println("Ingrese el valor de la acelaacion");
		a =sc.nextDouble();
		
		f=m*a;
		
		System.out.println("El valor de fuerza de un cuerpo es = "+f);
		
		
		

	}

}
