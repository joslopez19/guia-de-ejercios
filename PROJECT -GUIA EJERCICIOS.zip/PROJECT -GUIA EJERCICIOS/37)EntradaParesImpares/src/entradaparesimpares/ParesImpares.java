package entradaparesimpares;

import java.util.Scanner;

public class ParesImpares {

	public static void main(String[] args) {
		// 37.	Escriba un programa que tenga como entrada “n” números 
		//enteros y que calcule el número de números pares e impares. 
		
		Scanner sc = new Scanner(System.in);
		
		
	System.out.println("Ingrese le numero entero a Leer");
	int n = sc.nextInt();
	
	int par=0;
	int impar=0;
	
	for (int i=0; i<n; i++) {
		
		System.out.println("Ingrese el entero");
		int num = sc.nextInt();
		
		if (num %2 == 0) {
			par++;
		}else {
			impar++;
		}
	}
    System.out.println("El numero entero Par es "+par);
    System.out.println("El numero entero Impar es "+impar);
	}

}
