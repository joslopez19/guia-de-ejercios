package EntradNumeros;

import java.util.Scanner;

public class LecturaNumeros {

	public static void main(String[] args) {
		// 30.	Escriba un programa que tenga como entrada la lectura de dos números llamados “X” y “Y” y que 
		//imprima una salida que corresponda a cada uno de los pares. 
		 
		//a)(-X, -Y) Entonces sumar los cuadrados de cada componente. 
	    //b)(-X, Y) Entonces restar al valor Y el valor de X. 
		//c)(X, -Y) Entonces dividir X entre Y 
		//d)(X, Y) Entonces verificar si X es mayor que Y, si es así sumarle a X el valor de Y, si no obtener la raíz cuadrada de X.
		
		Scanner sc = new Scanner(System.in);
	
		
		System.out.println("Ingrese el valor de X");
		double x =sc.nextDouble();
		System.out.println("Ingrese el valor de y");
		double y =sc.nextDouble();
		
		if ( x < 0 && y < 0) {
			double result = Math.pow(x, 2)+ Math.pow(y, 2);
			
		System.out.println("El resultado de resta de X de Y = " +result);
			
			
		} else if (x<0 && y >=0) {
			
			double result =x/y;
			System.out.println(" El resultado de devidir X de Y es = "+result);
		} else if (x>y) {
			double result =x+y;
			
			System.out.println("El resultado de sumar X de Y");
		}else {
			double result = Math.sqrt(x);
			System.out.println("La raiz cuadra de X es ="+result);
		}
		
	}	

	}


