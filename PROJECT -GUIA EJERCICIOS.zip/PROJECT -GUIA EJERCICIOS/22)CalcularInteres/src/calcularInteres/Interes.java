package calcularInteres;

import java.util.Scanner;

public class Interes {
	
	public static void main (String [] args ) {
	// 22.	Escribir un programa para calcular el interés de una capital conforme a la siguiente condición
	// Si el capital prestado es mayor que 10,000 dólares entonces la tasa es del 7% en caso contrario 	
	// del 6%, debe imprimir el capital y su interés. 
		
		Scanner sc = new Scanner(System.in);
		
		double c = 'n';
		
        System.out.print("Ingrese el monto del capital: ");
        c = sc.nextDouble();
        
        double Tipointeres = (c > 10000) ? 0.07*100 : 0.06*100;
        double interes = c * Tipointeres;
        System.out.println("El interés del capital es: " + Tipointeres +"%");
    }
}
 



				
		
		
		
		

