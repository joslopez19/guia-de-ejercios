package leerEnteros;

import java.util.Scanner;

public class LeaEnteros {

	public static void main(String[] args) {
		// 29.	Escriba un programa que lea dos números enteros positivos distintos y 
		//escriba la diferencia entre el mayor y el menor. Asegúrese que su programa escriba 
		//por ejemplo 8 si los números son 10 y 2 o bien 2 y 10. 
		
		
		Scanner sc = new Scanner(System.in);
		
		int num1 = 'n';
		int num2 = 'n';
		
		
		System.out.println("Ingrese el primero entero positivo");
		num1 = sc.nextInt();
		System.out.println("Ingrese el segundo entero positivo");
		num2 = sc.nextInt();
		
		int diferencia = Math.abs(num1-num2);
		
		System.out.println("la diferencia entre el numero mayor y el menor = "+ diferencia);
		
	
		
		
	}

}
