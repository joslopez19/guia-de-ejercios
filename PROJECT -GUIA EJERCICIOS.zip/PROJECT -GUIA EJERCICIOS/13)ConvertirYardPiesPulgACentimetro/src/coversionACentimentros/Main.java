package coversionACentimentros;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 13.Convertir Y yardas, F pies y I pulgadas a Centímetros.  
		
		Scanner sc = new Scanner(System.in);
		
		int yardas = 'n';
		int pies = 'n';
		int pulgadas = 'n';
		
		System.out.println("Ingrese el numero de yardas a convertira CM ");
		yardas = sc.nextInt();
		System.out.println("Ingrese el numero de pies a convertir a CM ");
		pies =sc.nextInt();
		System.out.println("Ingrese el numero de pulgadas a convertir a CM ");
		pulgadas = sc.nextInt();
		

		
		double cmz =  yardas*91.44;                     
		double cmy =  pies*30.48;                         
        double cmx =  pulgadas* 2.54;  
        
		System.out.println("El numero de yardas en centrimetros es = "+cmz);
		System.out.println("El numero de pies en centrimetros es = "+cmy);
		System.out.println("El numero de pulgadas en centrimetros es ="+cmx);
		
		 
		 
		
		

	}

}
