package promedionotas;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 12.	Obtener el promedio de N notas.
		//se agrega 7 notas de alumnos y calcula el promedio
		
		Scanner sc= new Scanner(System.in);
		
		double [] notas = {96,88,91,85,70,81,98};  // arreglo de notas
		double suma = 0;                           // la variable que almacena la suma de las notas
		
		for ( int i = 0; i < notas.length; i++) {
		suma += notas[i]; 	
}
		double promedio = suma/notas.length;
		System.out.println("El promedio de las notas los alumnos es = "+promedio);
		
 }
}
	
