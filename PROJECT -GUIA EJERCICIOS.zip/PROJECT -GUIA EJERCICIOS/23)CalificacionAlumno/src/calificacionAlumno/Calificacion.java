package calificacionAlumno;

public class Calificacion {
	
	public  static void main(String [] args) {
		// 23.Escribir un programa que lea la calificación de un alumno e imprima el mensaje de aprobado si 
		//su calificación es mayor o igual a 60, en caso contrario imprima reprobado. 
		 
  
		
		
	}

}
