package calificaciones;

import java.util.Scanner;

public class EntradaNotas {

	public static void main(String[] args) {
		// 32.Las calificaciones de los alumnos en un instituto son consideradas de la siguiente forma: 
		// a) A es 90 o más. 
		// b)B es al menos 80 pero menos de 90. 
		// c)C es al menos 70 pero menos de 80. 
		// d)D es al menos 65 pero menos de 70.
		// e)	E es menos de 65. 
		//Escriba un programa que considere la entrada de nota en número e imprima su codificación en letra
		
  Scanner sc =new Scanner(System.in);
  
  int calif = 'n';
		
  System.out.println("La calificación la calificacion del estudiante");
   calif = sc.nextInt();
   
   if (calif>=90) {
	   System.out.println("Las calificaciones de la letra del estudiante es = A");
   } else if(calif >=80) {
	   System.out.println("Las calificaciones de la letra del estudiante es = B");
   }else if(calif >=70) {
	   System.out.println("Las calificaciones de la letra del estudiante es = C");   
   }else if(calif >=65) {
	   System.out.println("Las calificaciones de la letra del estudiante es = D");
   } else {
	   System.out.println("Las calificaciones de la letra del estudiante es= E");  
   }
  	
 }

}
