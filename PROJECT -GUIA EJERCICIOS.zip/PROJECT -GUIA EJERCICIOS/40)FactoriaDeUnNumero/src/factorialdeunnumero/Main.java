package factorialdeunnumero;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// calcule un factorial de un numero entero
	
		Scanner tc = new Scanner(System.in);
		
		int num, fact=1;
		
		System.out.println("Ingrese un numero");
	    num = tc.nextInt();
	    
	    for(int i=1;  i<=num;  i++) {
	    	
	    fact=fact*i;
	   
	    
	    }
		 System.out.println(num+"!="+ fact);
		 
		 
		
	}

}
